/*
 * Name: Zach Lavengco/Tristan Maltizo
 * Email: zlaven2@uic.edu/maltizo2@uic.edu
 * Project 3 
 * File for the Baccarat Game
*/

import java.util.ArrayList;

public class BaccaratGame {
    private ArrayList<Card> playerHand;
    private ArrayList<Card> bankerHand;
    private BaccaratDealer theDealer;
    private double bid;
    private double totalWinnings;
    private String hand;

    public BaccaratGame(double bid, String hand) {
        this.theDealer = new BaccaratDealer();
        this.theDealer.generateDeck();
        this.playerHand = this.theDealer.dealHand();
        this.bankerHand = this.theDealer.dealHand();
        this.bid = bid;
        this.hand = hand;
    }

    public double evaluateWinnings() {
        String winner = BaccaratGameLogic.whoWon(this.bankerHand, this.playerHand);
        if (winner.equals(this.hand)) {
            // Need to charge 5% commission if banker won
            if (this.hand.equals("Banker"))
                return this.bid * (1 - 0.05);
            else if (this.hand.equals("Player"))
            	return this.bid;
            else if (this.hand.equals("Draw"))
            	return this.bid * 8;
        }
        return -1 * this.bid;
    }

    public ArrayList<Card> getPlayerHand() {
        return playerHand;
    }

    public ArrayList<Card> getBankerHand() {
        return bankerHand;
    }

    public BaccaratDealer getTheDealer() {
        return theDealer;
    }

    public double getBid() {
        return bid;
    }

    public double getTotalWinnings() {
        return totalWinnings;
    }

    public String getHand() {
        return hand;
    }
}