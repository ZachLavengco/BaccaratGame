/*
 * Name: Zach Lavengco/Tristan Maltizo
 * Email: zlaven2@uic.edu/maltizo2@uic.edu
 * Project 3 
 * Server file for conversing with Client
*/
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.scene.control.ListView;

public class Server{

	String ip;
	int port;
	int count = 1;	
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	
	TheServer server;
	private Consumer<Serializable> callback;
	BaccaratInfo res;
	Card playerDrawCard;
    Card bankerDrawCard;
	
	
	Server(Consumer<Serializable> call, int port){
		
		//gameInfo = new BaccaratInfo();
		callback = call;
		this.port = port;
		server = new TheServer();
		server.start();
	}
	
	
	public class TheServer extends Thread{
		
		public void run() {
		
			try(ServerSocket mysocket = new ServerSocket(port);){
				System.out.println("Server is waiting for a client!");
		  
			    while(true) {
			    	ClientThread c = new ClientThread(mysocket.accept(), count);
					callback.accept("Client has connected to server: " + "client #" + count);
					clients.add(c);
					callback.accept(clients.size() + " client(s) currently in server.");
					c.start();
					count++;
					
					
//			    	if (clients.size() < 4) {
//			    		ClientThread c = new ClientThread(mysocket.accept(), count);
//						callback.accept("client has connected to server: " + "client #" + count);
//						clients.add(c);
//						c.start();
//	
//						count++;
//			    	} else {
//			    		callback.accept("Server has reached maximum capacity (4). Client cannot join the server.");
//			    		while(true) {
//			    			if (clients.size() < 4) {
//			    				break;
//			    			}
//			    		}
//			    		continue;
//			    	}
					
			    }

			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}

		class ClientThread extends Thread{
			
		
			Socket connection;
			int count;
			ObjectInputStream in;
			ObjectOutputStream out;
			BaccaratGame game;
			
			ClientThread(Socket s, int count){
				this.connection = s;
				this.count = count;	
			}
			
			public void updateClientGame(BaccaratInfo update) {
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
						t.out.writeObject(update);
						t.out.reset();
					}
					catch(Exception e) {
						System.out.println("Something went wrong updating clients");
					}
				}
			}
			
			public void updateClients(String message) {
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
						t.out.writeObject(message);
						t.out.reset();
					}
					catch(Exception e) {
						System.out.println("Something went wrong updating clients");
					}
				}
			}
			
			public void run(){
					
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}
				
				updateClients("You have connected to the server.") ;
				updateClients("You are client #" + count);
					
//				 while(true) {
//					    try {
//					    	String data = in.readObject().toString();
//					    	callback.accept("client: " + count + " sent: " + data);
//					    	updateClients("client #"+count+" said: "+data);
//					    	
//					    	}
//					    catch(Exception e) {
//					    	callback.accept("OOOOPPs...Something wrong with the socket from client: " + count + "....closing down!");
//					    	updateClients("Client #"+count+" has left the server!");
//					    	clients.remove(this);
//					    	break;
//					    }
//					}
//				}//end of run
				
				while (!this.connection.isClosed()) {
	                try {
	                    BaccaratInfo req = (BaccaratInfo) in.readObject();
	                    
	                    callback.accept("Client #" + this.count + " sent a request: ");
	                    callback.accept("\tBid: " + req.getBid() + "\tHand: " + req.getHand() + "\n");
	                    
	                    game = new BaccaratGame(req.getBid(), req.getHand());
	                    BaccaratDealer dealer = game.getTheDealer();
	                    dealer.shuffleDeck();
	                    BaccaratInfo res = new BaccaratInfo(req.getBid(), req.getHand());

	                    ArrayList<Card> bankerHand = game.getBankerHand();
	                    ArrayList<Card> playerHand = game.getPlayerHand();
	                    
	                    playerDrawCard = dealer.drawOne();
	                    playerHand.add(playerDrawCard);
	                    updateClients("Player Drew Card: " + playerDrawCard.value + playerDrawCard.suite);
	                    updateClients(". Player Score: " + BaccaratGameLogic.addHandUp(playerHand));
	                    //System.out.println("Player Drew Card: " + playerDrawCard.value + playerDrawCard.suite);
                		res.playerHand.add(playerDrawCard.value + playerDrawCard.suite);
	                    
                		playerDrawCard = dealer.drawOne();
                		playerHand.add(playerDrawCard);
	                    updateClients("Player Drew Card: " + playerDrawCard.value + playerDrawCard.suite);
	                    updateClients(". Player Score: " + BaccaratGameLogic.addHandUp(playerHand));
	                    //System.out.println("Player Drew Card: " + playerDrawCard.value + playerDrawCard.suite);
                		res.playerHand.add(playerDrawCard.value + playerDrawCard.suite);
                		
                		bankerDrawCard = dealer.drawOne();
	                    bankerHand.add(bankerDrawCard);
	                    updateClients("Banker Drew Card: " + bankerDrawCard.value+bankerDrawCard.suite);
	                    updateClients("- Banker Score: " + BaccaratGameLogic.addHandUp(bankerHand));
	                    //System.out.println("Banker Drew Card: " + bankerDrawCard.value+bankerDrawCard.suite);
                        res.bankerHand.add(bankerDrawCard.value + bankerDrawCard.suite);
                        
                        bankerDrawCard = dealer.drawOne();
	                    bankerHand.add(bankerDrawCard);
	                    updateClients("Banker Drew Card: " + bankerDrawCard.value+bankerDrawCard.suite);
	                    updateClients("- Banker Score: " + BaccaratGameLogic.addHandUp(bankerHand));
	                    //System.out.println("Banker Drew Card: " + bankerDrawCard.value+bankerDrawCard.suite);
                        res.bankerHand.add(bankerDrawCard.value + bankerDrawCard.suite);
                        
                        playerDrawCard = null;
                        bankerDrawCard = null;
                        
                        updateClients("\tCalculating scores...");
                        TimeUnit.SECONDS.sleep(3);

	                    // Check if we need to draw an additional card...
                        if (BaccaratGameLogic.evaluatePlayerDraw(playerHand) || BaccaratGameLogic.evaluateBankerDraw(bankerHand, playerDrawCard)) {
	                    	updateClients("\tNot natural win.");
                        } else {
	                    	updateClients("\tNatural win.");
                        }
                        TimeUnit.SECONDS.sleep(1);
                        
                        updateClients("\tWaiting for results...");
                        TimeUnit.SECONDS.sleep(3);
                        
                        if (BaccaratGameLogic.evaluatePlayerDraw(playerHand)) {
                        	playerDrawCard = dealer.drawOne();
                    		playerHand.add(playerDrawCard);
                    		updateClients("\t\tPlayer Drew Another Card.");
    	                    updateClients("Player Drew Card: " + playerDrawCard.value + playerDrawCard.suite);
    	                    updateClients(". Player Score: " + BaccaratGameLogic.addHandUp(playerHand));
    	                    //System.out.println("Player Drew Card: " + playerDrawCard.value + playerDrawCard.suite);
                    		res.playerHand.add(playerDrawCard.value + playerDrawCard.suite);
                    		TimeUnit.SECONDS.sleep(3);
                    	}
                        if (BaccaratGameLogic.evaluateBankerDraw(bankerHand, playerDrawCard)) {
                        	bankerDrawCard = dealer.drawOne();
    	                    bankerHand.add(bankerDrawCard);
    	                    updateClients("\t\tBanker Drew Another Card.");
    	                    updateClients("Banker Drew Card: " + bankerDrawCard.value+bankerDrawCard.suite);
    	                    updateClients("- Banker Score: " + BaccaratGameLogic.addHandUp(bankerHand));
    	                    //System.out.println("Banker Drew Card: " + bankerDrawCard.value+bankerDrawCard.suite);
                            res.bankerHand.add(bankerDrawCard.value + bankerDrawCard.suite);
                            TimeUnit.SECONDS.sleep(3);
                        }
	                    
                        res.setPlayerScore(BaccaratGameLogic.addHandUp(playerHand));
                        res.setBankerScore(BaccaratGameLogic.addHandUp(bankerHand));
                        

	                    // Set winner
	                    res.setWinner(BaccaratGameLogic.whoWon(game.getBankerHand(), game.getPlayerHand()));
	                    res.setWinnings(req.getWinnings() + game.evaluateWinnings());
	                    
	                    if (res.getWinner() == "Banker") {
	                    	res.setBankerWins(res.getBankerWins() + 1);
	                    	updateClients("\t\t\tBanker Wins");
	                    } else if (res.getWinner() == "Player") {
	                    	res.setPlayerWins(res.getPlayerWins() + 1);
	                    	updateClients("\t\t\tPlayer Wins");
	                    } else {
	                    	updateClients("\t\t\tTie");
	                    }
	                    
	                    updateClients(".\tPlayer Wins: " + res.getPlayerWins());
	                    updateClients("-\tBanker Wins: " + res.getBankerWins());
	                    
	                    //System.out.println(res.playerHand);
	                    //System.out.println(res.bankerHand);
	                    //System.out.println(res.getHand());
	                    //System.out.println(res.getWinner());
	                    //System.out.println(res.getBid());
	                    //System.out.println(res.getWinnings());
	                    //System.out.println(res.getPlayerScore());
	                    //System.out.println(res.getBankerScore());
	                    
	                    
	                    if (game.evaluateWinnings() >= 0) {
	                    	callback.accept("\t\tClient #" + this.count + " just won " + game.evaluateWinnings() + ".");
	                    	updateClients("\t\t\tYou just won " + game.evaluateWinnings() + ".");
	                    } else {
	                    	callback.accept("\t\tClient #" + this.count + " just lost " + game.evaluateWinnings() + ".");
	                    	updateClients("\t\t\tYou just lost " + game.evaluateWinnings() + ".");
	                    }
	                    
	                    updateClientGame(res);
	                    
	                } catch (Exception e) {
	                    callback.accept("Error: Could not fetch request from client #" + this.count);
	                    try {
	                        this.connection.close();
	                        
	                        /* remove client from ArrayList of clients */
	                        clients.remove(this);

	                    } catch (IOException e1) {
	                        callback.accept("Error: Could not close connection for client #" + this.count);
	                    }
	                }
	            }
	            callback.accept("Connection closed for client #" + this.count);
	        }
	    }
}//end of client thread
	

	
