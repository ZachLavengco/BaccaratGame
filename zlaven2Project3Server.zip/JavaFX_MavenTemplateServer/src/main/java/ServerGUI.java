/*
 * Name: Zach Lavengco/Tristan Maltizo
 * Email: zlaven2@uic.edu/maltizo2@uic.edu
 * Project 3 
 * ServerGUI file for displaying
*/
import java.util.HashMap;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ServerGUI extends Application {
	
	TextField portTxtField;
	Button startServerButton;
	HashMap<String, Scene> sceneMap;
	GridPane grid;
	VBox vBox;
	Scene startScene;
	BorderPane startPane;

	Text ipText, portTxt, numClientsText, serverHeaderText;
	Button serverOn, serverOff;
	VBox serverBox;
	HBox serverButtonBox, allPlayers;
	Scene serverScene;
	BorderPane serverPane;
	Server serverConnection;
	String displayNumOfClients, serverHeadStr, portStr;
	
	ListView<String> serverList,
		p1List, p2List, p3List, p4List;
    
    // Variables needed to connect client to server via user input
	int portNumber = 5555;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Welcome to Baccarat");
		
		this.startServerButton = new Button("Turn Server On");		
		this.startServerButton.setOnAction(e->{ 
			/* Get port number from current input in the TextField */
			this.portNumber = Integer.parseInt(this.portTxtField.getText()); // getText() returns a string, convert to int
			
			this.serverConnection = new Server(data -> {
				Platform.runLater(()->{
					serverList.getItems().add(data.toString());
				});
			}, this.portNumber);
			
			primaryStage.setScene(sceneMap.get("server"));
			primaryStage.setTitle("This is the Server");
		});
		
		// Enter port and ip address
		String portStr = "Enter port number below: ";
		this.portTxt = new Text(portStr);
		this.portTxtField = new TextField();
		
		String ipStr = "Server: 127.0.0.1";
		this.ipText = new Text(ipStr);
		this.portTxtField.setStyle("-fx-pref-width: 150px");
		
		// Showing visuals
		this.vBox = new VBox(portTxt, portTxtField, ipText, startServerButton);
		this.vBox.setSpacing(10);
		this.startPane = new BorderPane();
		this.startPane.setPadding(new Insets(70));
		this.startPane.setCenter(vBox);
		
		this.startScene = new Scene(startPane, 300,300);
		
		this.serverList = new ListView<String>();
		this.sceneMap = new HashMap<String, Scene>();
		this.sceneMap.put("server",  createServerGui());
		
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>( ) {
			@Override
			public void handle(WindowEvent t) {
				Platform.exit();
				System.exit(0);
			}
		});
		
		primaryStage.setScene(startScene);
		primaryStage.show();
	}

	public Scene createServerGui() {
		
		BorderPane pane = new BorderPane();
		pane.setPadding(new Insets(30));
		pane.setStyle("-fx-background-color: lavender");
		
		
		//// Top Of Pane
		
		// Display server state and buttons
		this.serverOff = new Button("Turn Off Server");
		
		this.serverButtonBox = new HBox(serverOff);
		this.serverButtonBox.setAlignment(Pos.CENTER);
		this.serverList = new ListView<String>();
		this.serverList.setStyle("-fx-pref-width: 400px");
		this.serverList.setStyle("-fx-pref-height: 200px");
		
		this.serverHeadStr = "Server State:";
		this.serverHeaderText = new Text(serverHeadStr);
		this.serverBox = new VBox(serverHeaderText, serverList, serverButtonBox);
		this.serverBox.setAlignment(Pos.CENTER);
		
		// button actions
		this.serverOff.setOnAction(e->{ 
			try {
				System.out.println("Server has closed");
				Platform.exit();
				System.exit(0);
				
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
		
		
		
		//// Set pane create scene
		pane.setTop(serverBox);
	
		return new Scene(pane, 500, 400);
		
	}
}
