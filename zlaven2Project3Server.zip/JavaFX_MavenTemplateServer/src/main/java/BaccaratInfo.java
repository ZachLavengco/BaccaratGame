import java.io.Serializable;
import java.util.ArrayList;

public class BaccaratInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    public ArrayList<String> playerHand = new ArrayList<>(); // ["1C", "12H"]
    public ArrayList<String> bankerHand = new ArrayList<>(); // ["3D", "4S"]
    private String hand,winner;
    private int playerWins,playerScore,bankerWins,bankerScore;
    private double bid,winnings;
    
    BaccaratInfo() {
    	hand = "";
    	winner = "";
    	playerWins = 0;
    	playerScore = 0;
    	bankerWins = 0;
    	bid = 0.0;
    	winnings = 0.0;
    	playerHand = new ArrayList<String>();
    	bankerHand = new ArrayList<String>();
    }
    BaccaratInfo(double bid, String hand) {
    	this.hand = hand;
    	winner = "";
    	playerWins = 0;
    	playerScore = 0;
    	bankerWins = 0;
    	this.bid = bid;
    	winnings = 0.0;
    	playerHand = new ArrayList<String>();
    	bankerHand = new ArrayList<String>();
    }

    public void setHand(String hand) {
    	this.hand = hand;
    }
    public void setWinner(String winner) {
    	this.winner = winner;
    }
    public void setPlayerWins(int wins) {
    	this.playerWins = wins;
    }
    public void setBankerWins(int wins) {
    	this.bankerWins = wins;
    }
    public void setBid(double bid) {
    	this.bid = bid;
    }
    public void setWinnings(double winnings) {
    	this.winnings = winnings;
    }
    public void setPlayerScore(int score) {
    	this.playerScore = score;
    }
    public void setBankerScore(int score) {
    	this.bankerScore = score;
    }
    
    public String getHand() {
    	return hand;
    }
    public String getWinner() {
    	return winner;
    }
    public int getPlayerWins() {
    	return playerWins;
    }
    public int getBankerWins() {
    	return bankerWins;
    }
    public double getBid() {
    	return bid;
    }
    public double getWinnings() {
    	return winnings;
    }
    public int getPlayerScore() {
    	return playerScore;
    }
    public int getBankerScore() {
    	return bankerScore;
    }
}