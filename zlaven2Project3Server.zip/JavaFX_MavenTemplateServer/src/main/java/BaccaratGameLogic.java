/*
 * Name: Zach Lavengco/Tristan Maltizo
 * Email: zlaven2@uic.edu/maltizo2@uic.edu
 * Project 3 
 * File for the Baccarat Game Logic
*/
import java.util.ArrayList;

public class BaccaratGameLogic {
    public static String whoWon(ArrayList<Card> bHand, ArrayList<Card> pHand) {
        int bankerHand = addHandUp(bHand);
        int playerHand = addHandUp(pHand);

        int playerDifference = 9 - playerHand;
        int bankerDifference = 9 - bankerHand;

        // The diff that is the smallest is the winner
        if (playerDifference < bankerDifference)
            return "Player";
        else if (bankerDifference < playerDifference)
            return "Banker";
        return "Draw";
    }

    public static int addHandUp(ArrayList<Card> hand) {
        int val = 0;
        for (Card c : hand)
        	val += c.getValue();

        if (val < 10)
            return val;
        return val % 10;
    }

    public static boolean evaluateBankerDraw(ArrayList<Card> hand, Card pCard) {
        int bTotal = addHandUp(hand);
        if (bTotal <= 2 || ((bTotal > 2 && bTotal < 7) && pCard != null)) { return true; }
        return false;
    }

    public static boolean evaluatePlayerDraw(ArrayList<Card> hand) {
        int pTotal = addHandUp(hand);
        return pTotal <= 5;
    }
}