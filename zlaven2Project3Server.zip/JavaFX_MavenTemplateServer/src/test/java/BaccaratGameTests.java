/*
 * Name: Zach Lavengco/Tristan Maltizo
 * Email: zlaven2@uic.edu/maltizo2@uic.edu
 * Project 3 
 * Test file for BaccaratGame.java
*/

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;


public class BaccaratGameTests {

    BaccaratGame game;

    @Test
    void testConstructor(){
    	game = new BaccaratGame(20.0,"Player");
    	assertEquals("Player", game.getHand());
    	assertEquals(20.0, game.getBid());
    }
    @Test
    void getBid(){
    	game = new BaccaratGame(30.0,"");
    	assertEquals(30.0, game.getBid());
    }
    @Test
    void getBid2(){
    	game = new BaccaratGame(40.0,"");
    	assertEquals(40.0, game.getBid());
    }

    @Test
    void winnings(){
    	game = new BaccaratGame(30.0,"");
    	ArrayList<Card> p = new ArrayList<Card>();
    	ArrayList<Card> b = new ArrayList<Card>();
    	
    }
    @Test
    void winnings2(){
    	game = new BaccaratGame(40.0,"");
    }
}