/*
 * Name: Zach Lavengco/Tristan Maltizo
 * Email: zlaven2@uic.edu/maltizo2@uic.edu
 * Project 3 
 * Test file for Card.java
*/

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class CardTests {

    Card card;

    @Test
    void testConstructor(){
    	card = new Card("Heart", 13);
    	assertEquals("Heart", card.getSuite());
    	assertEquals(13, card.getValue());
    }

    @Test
    void testSetGetValue(){
    	card = new Card(" ", 0);
    	card.setValue(2);
    	card.setSuite("Diamond");
    	assertEquals("Diamond", card.getSuite());
    	assertEquals(2, card.getValue());
    }
    @Test
    void testSetGetValue2(){
    	card = new Card(" ", 0);
    	card.setValue(4);
    	card.setSuite("Spade");
    	assertEquals("Spade", card.getSuite());
    	assertEquals(4, card.getValue());
    }
}
