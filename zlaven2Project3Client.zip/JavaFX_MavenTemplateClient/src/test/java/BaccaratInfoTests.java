import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class BaccaratInfoTests {
	
	// All tests for BaccaratInfo
	private BaccaratInfo baca = new BaccaratInfo();
	
	@Test
	void BaccaratInfoConstructorBlank() {
		baca = new BaccaratInfo();
		assertEquals("", baca.getHand());
		assertEquals("", baca.getWinner());
		assertEquals(0, baca.getPlayerWins());
		assertEquals(0, baca.getBankerWins());
		assertEquals(0, baca.getBid());
		assertEquals(0.0, baca.getWinnings());
		assertEquals(0, baca.getPlayerScore());
		assertEquals(0, baca.getBankerScore());
	}
	@Test
	void BaccaratInfoConstructorBidHandInput() {
		baca = new BaccaratInfo(25, "Banker");
		assertEquals("Banker", baca.getHand());
		assertEquals("", baca.getWinner());
		assertEquals(0, baca.getPlayerWins());
		assertEquals(0, baca.getBankerWins());
		assertEquals(25, baca.getBid());
		assertEquals(0.0, baca.getWinnings());
		assertEquals(0, baca.getPlayerScore());
		assertEquals(0, baca.getBankerScore());
	}
	@Test
	void BaccaratInfoSetGetHand() {
		baca = new BaccaratInfo();
		baca.setHand("Player");
		assertEquals("Player", baca.getHand());
	}
	@Test
	void BaccaratInfoSetGetHand2() {
		baca = new BaccaratInfo();
		baca.setHand("Banker");
		assertEquals("Banker", baca.getHand());
	}
	@Test
	void BaccaratInfoSetGetWinner() {
		baca = new BaccaratInfo();
		baca.setWinner("Player");
		assertEquals("Player", baca.getWinner());
	}
	@Test
	void BaccaratInfoSetGetWinner2() {
		baca = new BaccaratInfo();
		baca.setWinner("Banker");
		assertEquals("Banker", baca.getWinner());
	}
	@Test
	void BaccaratInfoSetGetPlayerWins2() {
		baca = new BaccaratInfo();
		baca.setPlayerWins(10);
		assertEquals(10, baca.getPlayerWins());
	}
	@Test
	void BaccaratInfoSetGetBankerWins() {
		baca = new BaccaratInfo();
		baca.setBankerWins(2);
		assertEquals(2, baca.getBankerWins());
	}
	@Test
	void BaccaratInfoSetGetBankerWins5() {
		baca = new BaccaratInfo();
		baca.setBankerWins(5);
		assertEquals(5, baca.getBankerWins());
	}
	@Test
	void BaccaratInfoSetGetBid() {
		baca = new BaccaratInfo();
		baca.setBid(20.0);
		assertEquals(20.0, baca.getBid());
	}
	@Test
	void BaccaratInfoSetGetBid2() {
		baca = new BaccaratInfo();
		baca.setBid(5.0);
		assertEquals(5.0, baca.getBid());
	}
	@Test
	void BaccaratInfoSetGetWinnnings() {
		baca = new BaccaratInfo();
		baca.setWinnings(20.0);
		assertEquals(20.0, baca.getWinnings());
	}
	@Test
	void BaccaratInfoSetGetWinnings2() {
		baca = new BaccaratInfo();
		baca.setWinnings(50.5);
		assertEquals(50.5, baca.getWinnings());
	}
	@Test
	void BaccaratInfoSetGetPlayerScore() {
		baca = new BaccaratInfo();
		baca.setPlayerScore(20);
		assertEquals(20, baca.getPlayerScore());
	}
	@Test
	void BaccaratInfoSetGetPlayerScore2() {
		baca = new BaccaratInfo();
		baca.setPlayerScore(20);
		assertEquals(20, baca.getPlayerScore());
	}
	@Test
	void BaccaratInfoSetGetBankerScore() {
		baca = new BaccaratInfo();
		baca.setBankerScore(30);
		assertEquals(30, baca.getBankerScore());
	}
	@Test
	void BaccaratInfoSetGetBankerScore2() {
		baca = new BaccaratInfo();
		baca.setBankerScore(10);
		assertEquals(10, baca.getBankerScore());
	}
}
