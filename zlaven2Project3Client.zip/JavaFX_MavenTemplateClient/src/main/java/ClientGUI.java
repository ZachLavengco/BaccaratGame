/*
 * Name: Zach Lavengco/Tristan Maltizo
 * Email: zlaven2@uic.edu/maltizo2@uic.edu
 * Project 3 
 * ClientGUI file for displaying
*/
import java.util.HashMap;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ClientGUI extends Application {

	BaccaratInfo bacca = new BaccaratInfo();
	BaccaratInfo res = new BaccaratInfo();
	Button clientChoice;
	Client clientConnection;
	BorderPane startPane;
	HBox buttonBox;
	VBox vBox;
	HashMap<String, Scene> sceneMap;
	Scene startScene;
	VBox clientBox;
	
	Text winnings, playerTxt, bankerTxt;
	TextField wagerTextField;
	Button draw, shuffle, wager, quitButton, bidPlayer, bidBanker, bidDraw, playButton;
	BorderPane bPane;
	ListView<String> resultList, playerCardList,bankerCardList,bScoreWinList,pScoreWinList;
	HBox enterBidBox,bidOnBox,startStopBox,bottomBox,pScoreBox,bScoreBox;
	VBox bidBox, centerBox, rightVBox, leftVBox;
	String playerScoreNum,playerWins, winningsNum, bankerWins,bankerScoreNum, whoWonStr;
	double winningsAmt;
	
	
	// Variables needed to connect client to server via user input
	String ipAddress;
	int portNumber;
	TextField getAddress;
	TextField getPortNumber;
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("Welcome to JavaFX CLIENT");

		this.clientChoice = new Button("Connect to Server");
		
		/* Get ipAddress and portNumber from the user using TextFields */
		this.getAddress = new TextField("127.0.0.1");
		this.getPortNumber = new TextField();
		this.getPortNumber.setPromptText("Enter port number");

		
		ipAddress = "127.0.0.1";
		portNumber = 5555;
		
		this.clientChoice.setOnAction(e-> {primaryStage.setScene(sceneMap.get("client"));
			primaryStage.setTitle("This is a client");

			/* Get ip address and port number from current input in the TextFields */
			ipAddress = getAddress.getText();
			portNumber = Integer.valueOf(getPortNumber.getText()); // getText() returns a string, convert to int

			clientConnection = new Client(data->{
				Platform.runLater(()->{
					if(data instanceof String) {
						String dataStr = data.toString();
						//System.out.println(dataStr);
						if (dataStr.charAt(0) == 'P') {
							playerCardList.getItems().add(data.toString());
						} else if (dataStr.charAt(0) == 'B') {
							bankerCardList.getItems().add(data.toString());
						} else if (dataStr.charAt(0) == '.') {
							pScoreWinList.getItems().add(data.toString());
						} else if (dataStr.charAt(0) == '-') {
							bScoreWinList.getItems().add(data.toString());
						} else {
							resultList.getItems().add(data.toString()); 
						}
						
					}
					else {
						res = (BaccaratInfo) data;
					}
				});
			}, ipAddress, portNumber);

			clientConnection.start();
		});

		this.buttonBox = new HBox(10, getAddress,getPortNumber);
		this.vBox = new VBox(clientChoice, buttonBox);
		this.vBox.setSpacing(20);
		startPane = new BorderPane();
		startPane.setPadding(new Insets(70));
		startPane.setCenter(vBox);

		startScene = new Scene(startPane, 500,300);
		
		//c1 = new TextField();
		//b1 = new Button("Send");
		//b1.setOnAction(e->{clientConnection.send(c1.getText()); c1.clear();});
		
		sceneMap = new HashMap<String, Scene>();
		sceneMap.put("client",  createClientGui());
		
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });

		primaryStage.setScene(startScene);
		primaryStage.show();
	}

	public Scene createClientGui() {

		whoWonStr = new String(bacca.getWinner());
		
		draw = new Button();
		draw.setText("Draw");

		shuffle = new Button();
		shuffle.setText("Shuffle Deck");

		wager = new Button();
		wager.setText("Wager");
		
		
		// Banker (Right)
		bankerTxt = new Text("Banker");
		bankerCardList = new ListView<String>();
		bankerCardList.setPrefHeight(150);
		bankerCardList.setPrefWidth(150);
		bankerCardList.getItems().add("Banker Cards Drawn:");
		
		bScoreWinList = new ListView<String>();
		bScoreWinList.setPrefHeight(100);
		bScoreWinList.setPrefWidth(200);
		bScoreWinList.getItems().add("Banker Wins and Card Score:");
		
		bScoreBox = new HBox(bankerCardList, bScoreWinList);
		rightVBox = new VBox(bankerTxt,bScoreBox);
		
		bScoreBox.setAlignment(Pos.CENTER);
		rightVBox.setAlignment(Pos.CENTER);
		bScoreBox.setSpacing(10);
		rightVBox.setSpacing(50);
		
		
		// Player (Left)=
		playerTxt = new Text("Player");
		playerCardList = new ListView<String>();
		playerCardList.setPrefHeight(150);
		playerCardList.setPrefWidth(150);
		playerCardList.getItems().add("Player Cards Drawn:");
		
		pScoreWinList = new ListView<String>();
		pScoreWinList.setPrefHeight(100);
		pScoreWinList.setPrefWidth(200);
		pScoreWinList.getItems().add("Player Wins and Card Score:");
		
		pScoreBox = new HBox(pScoreWinList, playerCardList);
		leftVBox = new VBox(playerTxt,pScoreBox);
		
		pScoreBox.setAlignment(Pos.CENTER);
		leftVBox.setAlignment(Pos.CENTER);
		pScoreBox.setSpacing(10);
		leftVBox.setSpacing(50);
		
		
		// Center
		resultList = new ListView<String>();
		centerBox = new VBox(resultList);
		centerBox.setPrefHeight(150);
		centerBox.setPrefWidth(150);
		centerBox.setAlignment(Pos.CENTER);
		
		
		// Bottom
		wagerTextField = new TextField();
		wagerTextField.setPromptText("Enter wager amount here");
		playButton = new Button("Play");
		playButton.setDisable(true);
		quitButton = new Button("Quit");
		
		bidPlayer = new Button("Bid On Player");
		bidBanker = new Button("Bid On Banker");
		bidDraw = new Button("Bid On Draw");
		
		enterBidBox = new HBox(wagerTextField);
		bidOnBox = new HBox(bidPlayer, bidBanker, bidDraw);
		bidBox = new VBox(enterBidBox,bidOnBox);
		startStopBox = new HBox(playButton, quitButton);
		bottomBox = new HBox(bidBox, startStopBox);
		
		enterBidBox.setAlignment(Pos.CENTER);
		bidBox.setAlignment(Pos.CENTER);
		bidOnBox.setAlignment(Pos.CENTER);
		bottomBox.setAlignment(Pos.CENTER);
		startStopBox.setSpacing(5);
		bottomBox.setSpacing(30);
		
		//clientBox = new VBox(listItems2);
		bPane = new BorderPane();
		bPane.setPadding(new Insets(50));
		bPane.setLeft(leftVBox);
		bPane.setRight(rightVBox);
		bPane.setCenter(centerBox);
		bPane.setBottom(bottomBox);
		BorderPane.setMargin(centerBox, new Insets(30));
		BorderPane.setMargin(bottomBox, new Insets(35));
		bPane.setStyle("-fx-background-color: darkgreen");
		
		//// BUTTON ACTIONS
		
		// BIDDING
		this.bidDraw.setOnAction(e-> {
			try {
				// send input wager and who you're betting on to server
				double bid = Double.valueOf(wagerTextField.getText());
				String hand = "Draw";
				bacca.setBid(bid);
				bacca.setHand(hand);
				playButton.setDisable(false);
				bidDraw.setDisable(true);
				bidBanker.setDisable(true);
				bidPlayer.setDisable(true);
				resultList.getItems().add("You have bet $" + bid + " on a Draw.");


			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
		// Testing BaccaratInfo send and receive
		this.bidBanker.setOnAction(e-> {
			try {
				// send input wager to server
				double bid = Double.valueOf(wagerTextField.getText());
				String hand = "Banker";
				bacca.setBid(bid);
				bacca.setHand(hand);
				playButton.setDisable(false);
				bidDraw.setDisable(true);
				bidBanker.setDisable(true);
				bidPlayer.setDisable(true);
				resultList.getItems().add("You have bet $" + bid + " on the Banker.");

			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
		// Testing BaccaratInfo send and receive
		this.bidPlayer.setOnAction(e-> {
			try {
				// send input wager to server
				double bid = Double.valueOf(wagerTextField.getText());
				String hand = "Player";
				bacca.setBid(bid);
				bacca.setHand(hand);
				playButton.setDisable(false);
				bidDraw.setDisable(true);
				bidBanker.setDisable(true);
				bidPlayer.setDisable(true);
				resultList.getItems().add("You have bet $" + bid + " on the Player.");
				
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
		
		// Play and Quit
		
		this.playButton.setOnAction(e-> {
			try {
				
				clientConnection.send(bacca);
				
				bacca = res;
				
				playButton.setDisable(true);
				bidDraw.setDisable(false);
				bidBanker.setDisable(false);
				bidPlayer.setDisable(false);
				
				bankerCardList.getItems().clear();
				playerCardList.getItems().clear();
				bScoreWinList.getItems().clear();
				pScoreWinList.getItems().clear();
				bankerCardList.getItems().add("Banker Cards Drawn:");
				bScoreWinList.getItems().add("Banker Wins and Card Score:");
				playerCardList.getItems().add("Player Cards Drawn:");
				pScoreWinList.getItems().add("Player Wins and Card Score:");
				
//				bankerWinsTxt.setText("Banker Wins: " + bacca.getBankerWins());
//				bankerScoreTxt.setText("Score: " + bacca.getBankerScore());
//				playerWinsTxt.setText("Player Wins: " + bacca.getPlayerWins());
//				playerScoreTxt.setText("Score: " + bacca.getPlayerScore());
//				winnings.setText("Winnings: " + bacca.getWinnings());
				
//				System.out.println("Banker Wins: " + bacca.getBankerWins());
//				System.out.println("Score: " + bacca.getBankerScore());
//				System.out.println("Player Wins: " + bacca.getPlayerWins());
//				System.out.println("Score: " + bacca.getPlayerScore());
//				System.out.println("Winnings: " + bacca.getWinnings());
				
			} catch (Exception e1) {
				System.out.println("Issues found in Play Button");
				e1.printStackTrace();
			}
		});
		this.quitButton.setOnAction(e-> {
			try {
				Platform.exit();
				System.exit(0);
				
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
		
		
		return new Scene(bPane);	
	}
}