/*
 * Name: Zach Lavengco/Tristan Maltizo
 * Email: zlaven2@uic.edu/maltizo2@uic.edu
 * Project 3 
 * Client file for conversing with Server
*/
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;

public class Client extends Thread{

	String ip;
	int port;
	Socket socketClient;
	ObjectOutputStream out;
	ObjectInputStream in;
	private Consumer<Serializable> callback;
	BaccaratInfo bacca;
	
//	Client(Consumer<Serializable> call){
//		callback = call;
//	}
	
	/* Client constructor needs ip address and port number as user input params to connect to the server */
	Client(Consumer<Serializable> call, String ip, int port){
		callback = call;
		this.ip = ip;
		this.port = port;
	}
	
	public void run() {
		
		try {
			socketClient= new Socket(ip,port);
		    out = new ObjectOutputStream(socketClient.getOutputStream());
		    in = new ObjectInputStream(socketClient.getInputStream());
		    socketClient.setTcpNoDelay(true);
		    System.out.printf("Client connected to server %s port %d\n", ip, port);
		}
		catch(Exception e) {
			System.out.printf("Could not connect to server %s port %d\n", ip, port);
		}
		
		while(true) {
			 
			try {
				Serializable data = (Serializable) in.readObject();
				callback.accept(data);
			}
			catch(Exception e) {}
		}
	
    }
	
//	public void send(String data) {
//		
//		try {
//			out.writeObject(data);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
	
	/* BaccaratInfo send/receive data methods */
	
	public void send(double bid, String hand) {
		try {
			bacca = new BaccaratInfo(bid, hand);
	        out.writeObject(bacca);
	        out.reset();
		} catch (IOException e) {
			System.out.printf("Client failed to send BaccaratInfo to Server.");
			e.printStackTrace();
		}
    }
	public void send(BaccaratInfo bacca) {
		try {
	        out.writeObject(bacca);
	        out.reset();
		} catch (IOException e) {
			System.out.printf("Client failed to send BaccaratInfo to Server.");
			e.printStackTrace();
		}
    }
}
